pywifi is written and maintained by Jiang Sheng-Jhih and
various contributors

# Contributors

- Thomas Bell https://github.com/bell345
- William Gaylord https://github.com/chibill
